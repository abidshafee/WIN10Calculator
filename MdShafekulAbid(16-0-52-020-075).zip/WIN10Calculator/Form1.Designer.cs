﻿namespace WIN10Calculator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.plusOrMinusBtn = new System.Windows.Forms.Button();
            this.zeroBtn = new System.Windows.Forms.Button();
            this.decPointBtn = new System.Windows.Forms.Button();
            this.eqBtn = new System.Windows.Forms.Button();
            this.plusBtn = new System.Windows.Forms.Button();
            this.threeBtn = new System.Windows.Forms.Button();
            this.twoBtn = new System.Windows.Forms.Button();
            this.oneBtn = new System.Windows.Forms.Button();
            this.minusBtn = new System.Windows.Forms.Button();
            this.sixBtn = new System.Windows.Forms.Button();
            this.fiveBtn = new System.Windows.Forms.Button();
            this.fourBtn = new System.Windows.Forms.Button();
            this.mulBtn = new System.Windows.Forms.Button();
            this.nineBtn = new System.Windows.Forms.Button();
            this.eightBtn = new System.Windows.Forms.Button();
            this.sevenBtn = new System.Windows.Forms.Button();
            this.divBtn = new System.Windows.Forms.Button();
            this.rootBtn = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.percentBtn = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.resultTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.historyBtn = new System.Windows.Forms.Button();
            this.clrBtn = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.tempLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // plusOrMinusBtn
            // 
            this.plusOrMinusBtn.BackColor = System.Drawing.Color.WhiteSmoke;
            this.plusOrMinusBtn.FlatAppearance.BorderSize = 0;
            this.plusOrMinusBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.plusOrMinusBtn.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.plusOrMinusBtn.Location = new System.Drawing.Point(1, 458);
            this.plusOrMinusBtn.Name = "plusOrMinusBtn";
            this.plusOrMinusBtn.Size = new System.Drawing.Size(74, 60);
            this.plusOrMinusBtn.TabIndex = 0;
            this.plusOrMinusBtn.Text = "+/-";
            this.plusOrMinusBtn.UseVisualStyleBackColor = false;
            // 
            // zeroBtn
            // 
            this.zeroBtn.BackColor = System.Drawing.Color.WhiteSmoke;
            this.zeroBtn.FlatAppearance.BorderSize = 0;
            this.zeroBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.zeroBtn.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zeroBtn.Location = new System.Drawing.Point(77, 458);
            this.zeroBtn.Name = "zeroBtn";
            this.zeroBtn.Size = new System.Drawing.Size(74, 60);
            this.zeroBtn.TabIndex = 1;
            this.zeroBtn.Text = "0";
            this.zeroBtn.UseVisualStyleBackColor = false;
            this.zeroBtn.Click += new System.EventHandler(this.zeroBtn_Click);
            // 
            // decPointBtn
            // 
            this.decPointBtn.BackColor = System.Drawing.Color.WhiteSmoke;
            this.decPointBtn.FlatAppearance.BorderSize = 0;
            this.decPointBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.decPointBtn.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.decPointBtn.Location = new System.Drawing.Point(153, 458);
            this.decPointBtn.Name = "decPointBtn";
            this.decPointBtn.Size = new System.Drawing.Size(74, 60);
            this.decPointBtn.TabIndex = 2;
            this.decPointBtn.Text = ".";
            this.decPointBtn.UseVisualStyleBackColor = false;
            this.decPointBtn.Click += new System.EventHandler(this.zeroBtn_Click);
            // 
            // eqBtn
            // 
            this.eqBtn.BackColor = System.Drawing.Color.MediumTurquoise;
            this.eqBtn.FlatAppearance.BorderSize = 0;
            this.eqBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.eqBtn.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.eqBtn.Location = new System.Drawing.Point(229, 458);
            this.eqBtn.Name = "eqBtn";
            this.eqBtn.Size = new System.Drawing.Size(91, 60);
            this.eqBtn.TabIndex = 3;
            this.eqBtn.Text = "=";
            this.eqBtn.UseVisualStyleBackColor = false;
            this.eqBtn.Click += new System.EventHandler(this.eqBtn_Click);
            // 
            // plusBtn
            // 
            this.plusBtn.BackColor = System.Drawing.Color.LightGray;
            this.plusBtn.FlatAppearance.BorderSize = 0;
            this.plusBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.plusBtn.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.plusBtn.Location = new System.Drawing.Point(229, 397);
            this.plusBtn.Name = "plusBtn";
            this.plusBtn.Size = new System.Drawing.Size(91, 60);
            this.plusBtn.TabIndex = 7;
            this.plusBtn.Text = "+";
            this.plusBtn.UseVisualStyleBackColor = false;
            this.plusBtn.Click += new System.EventHandler(this.operator_click);
            // 
            // threeBtn
            // 
            this.threeBtn.BackColor = System.Drawing.Color.WhiteSmoke;
            this.threeBtn.FlatAppearance.BorderSize = 0;
            this.threeBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.threeBtn.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.threeBtn.Location = new System.Drawing.Point(153, 397);
            this.threeBtn.Name = "threeBtn";
            this.threeBtn.Size = new System.Drawing.Size(74, 60);
            this.threeBtn.TabIndex = 6;
            this.threeBtn.Text = "3";
            this.threeBtn.UseVisualStyleBackColor = false;
            this.threeBtn.Click += new System.EventHandler(this.zeroBtn_Click);
            // 
            // twoBtn
            // 
            this.twoBtn.BackColor = System.Drawing.Color.WhiteSmoke;
            this.twoBtn.FlatAppearance.BorderSize = 0;
            this.twoBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.twoBtn.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.twoBtn.Location = new System.Drawing.Point(77, 397);
            this.twoBtn.Name = "twoBtn";
            this.twoBtn.Size = new System.Drawing.Size(74, 60);
            this.twoBtn.TabIndex = 5;
            this.twoBtn.Text = "2";
            this.twoBtn.UseVisualStyleBackColor = false;
            this.twoBtn.Click += new System.EventHandler(this.zeroBtn_Click);
            // 
            // oneBtn
            // 
            this.oneBtn.BackColor = System.Drawing.Color.WhiteSmoke;
            this.oneBtn.FlatAppearance.BorderSize = 0;
            this.oneBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.oneBtn.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.oneBtn.Location = new System.Drawing.Point(1, 397);
            this.oneBtn.Name = "oneBtn";
            this.oneBtn.Size = new System.Drawing.Size(74, 60);
            this.oneBtn.TabIndex = 4;
            this.oneBtn.Text = "1";
            this.oneBtn.UseVisualStyleBackColor = false;
            this.oneBtn.Click += new System.EventHandler(this.zeroBtn_Click);
            // 
            // minusBtn
            // 
            this.minusBtn.BackColor = System.Drawing.Color.LightGray;
            this.minusBtn.FlatAppearance.BorderSize = 0;
            this.minusBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.minusBtn.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.minusBtn.Location = new System.Drawing.Point(229, 336);
            this.minusBtn.Name = "minusBtn";
            this.minusBtn.Size = new System.Drawing.Size(91, 60);
            this.minusBtn.TabIndex = 11;
            this.minusBtn.Text = "-";
            this.minusBtn.UseVisualStyleBackColor = false;
            this.minusBtn.Click += new System.EventHandler(this.operator_click);
            // 
            // sixBtn
            // 
            this.sixBtn.BackColor = System.Drawing.Color.WhiteSmoke;
            this.sixBtn.FlatAppearance.BorderSize = 0;
            this.sixBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sixBtn.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sixBtn.Location = new System.Drawing.Point(153, 336);
            this.sixBtn.Name = "sixBtn";
            this.sixBtn.Size = new System.Drawing.Size(74, 60);
            this.sixBtn.TabIndex = 10;
            this.sixBtn.Text = "6";
            this.sixBtn.UseVisualStyleBackColor = false;
            this.sixBtn.Click += new System.EventHandler(this.zeroBtn_Click);
            // 
            // fiveBtn
            // 
            this.fiveBtn.BackColor = System.Drawing.Color.WhiteSmoke;
            this.fiveBtn.FlatAppearance.BorderSize = 0;
            this.fiveBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.fiveBtn.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fiveBtn.Location = new System.Drawing.Point(77, 336);
            this.fiveBtn.Name = "fiveBtn";
            this.fiveBtn.Size = new System.Drawing.Size(74, 60);
            this.fiveBtn.TabIndex = 9;
            this.fiveBtn.Text = "5";
            this.fiveBtn.UseVisualStyleBackColor = false;
            this.fiveBtn.Click += new System.EventHandler(this.zeroBtn_Click);
            // 
            // fourBtn
            // 
            this.fourBtn.BackColor = System.Drawing.Color.WhiteSmoke;
            this.fourBtn.FlatAppearance.BorderSize = 0;
            this.fourBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.fourBtn.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fourBtn.Location = new System.Drawing.Point(1, 336);
            this.fourBtn.Name = "fourBtn";
            this.fourBtn.Size = new System.Drawing.Size(74, 60);
            this.fourBtn.TabIndex = 8;
            this.fourBtn.Text = "4";
            this.fourBtn.UseVisualStyleBackColor = false;
            this.fourBtn.Click += new System.EventHandler(this.zeroBtn_Click);
            // 
            // mulBtn
            // 
            this.mulBtn.BackColor = System.Drawing.Color.LightGray;
            this.mulBtn.FlatAppearance.BorderSize = 0;
            this.mulBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mulBtn.Font = new System.Drawing.Font("Malgun Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mulBtn.Location = new System.Drawing.Point(229, 275);
            this.mulBtn.Name = "mulBtn";
            this.mulBtn.Size = new System.Drawing.Size(91, 60);
            this.mulBtn.TabIndex = 15;
            this.mulBtn.Text = "×";
            this.mulBtn.UseVisualStyleBackColor = false;
            this.mulBtn.Click += new System.EventHandler(this.operator_click);
            // 
            // nineBtn
            // 
            this.nineBtn.BackColor = System.Drawing.Color.WhiteSmoke;
            this.nineBtn.FlatAppearance.BorderSize = 0;
            this.nineBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nineBtn.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nineBtn.Location = new System.Drawing.Point(153, 275);
            this.nineBtn.Name = "nineBtn";
            this.nineBtn.Size = new System.Drawing.Size(74, 60);
            this.nineBtn.TabIndex = 14;
            this.nineBtn.Text = "9";
            this.nineBtn.UseVisualStyleBackColor = false;
            this.nineBtn.Click += new System.EventHandler(this.zeroBtn_Click);
            // 
            // eightBtn
            // 
            this.eightBtn.BackColor = System.Drawing.Color.WhiteSmoke;
            this.eightBtn.FlatAppearance.BorderSize = 0;
            this.eightBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.eightBtn.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.eightBtn.Location = new System.Drawing.Point(77, 275);
            this.eightBtn.Name = "eightBtn";
            this.eightBtn.Size = new System.Drawing.Size(74, 60);
            this.eightBtn.TabIndex = 13;
            this.eightBtn.Text = "8";
            this.eightBtn.UseVisualStyleBackColor = false;
            this.eightBtn.Click += new System.EventHandler(this.zeroBtn_Click);
            // 
            // sevenBtn
            // 
            this.sevenBtn.BackColor = System.Drawing.Color.WhiteSmoke;
            this.sevenBtn.FlatAppearance.BorderSize = 0;
            this.sevenBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sevenBtn.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sevenBtn.Location = new System.Drawing.Point(1, 275);
            this.sevenBtn.Name = "sevenBtn";
            this.sevenBtn.Size = new System.Drawing.Size(74, 60);
            this.sevenBtn.TabIndex = 12;
            this.sevenBtn.Text = "7";
            this.sevenBtn.UseVisualStyleBackColor = false;
            this.sevenBtn.Click += new System.EventHandler(this.zeroBtn_Click);
            // 
            // divBtn
            // 
            this.divBtn.BackColor = System.Drawing.Color.LightGray;
            this.divBtn.FlatAppearance.BorderSize = 0;
            this.divBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.divBtn.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.divBtn.Location = new System.Drawing.Point(229, 213);
            this.divBtn.Name = "divBtn";
            this.divBtn.Size = new System.Drawing.Size(91, 60);
            this.divBtn.TabIndex = 19;
            this.divBtn.Text = "÷";
            this.divBtn.UseVisualStyleBackColor = false;
            this.divBtn.Click += new System.EventHandler(this.operator_click);
            // 
            // rootBtn
            // 
            this.rootBtn.BackColor = System.Drawing.Color.LightGray;
            this.rootBtn.FlatAppearance.BorderSize = 0;
            this.rootBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rootBtn.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rootBtn.Location = new System.Drawing.Point(153, 213);
            this.rootBtn.Name = "rootBtn";
            this.rootBtn.Size = new System.Drawing.Size(74, 60);
            this.rootBtn.TabIndex = 18;
            this.rootBtn.Text = "√x";
            this.rootBtn.UseVisualStyleBackColor = false;
            this.rootBtn.Click += new System.EventHandler(this.rootBtn_Click);
            // 
            // button20
            // 
            this.button20.BackColor = System.Drawing.Color.LightGray;
            this.button20.FlatAppearance.BorderSize = 0;
            this.button20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button20.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button20.Location = new System.Drawing.Point(1, 213);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(74, 60);
            this.button20.TabIndex = 16;
            this.button20.Text = "1/x";
            this.button20.UseVisualStyleBackColor = false;
            this.button20.Click += new System.EventHandler(this.button20_Click);
            // 
            // button22
            // 
            this.button22.BackColor = System.Drawing.Color.LightGray;
            this.button22.FlatAppearance.BorderSize = 0;
            this.button22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button22.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button22.Location = new System.Drawing.Point(153, 152);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(74, 60);
            this.button22.TabIndex = 22;
            this.button22.Text = "C";
            this.button22.UseVisualStyleBackColor = false;
            this.button22.Click += new System.EventHandler(this.button22_Click);
            // 
            // button23
            // 
            this.button23.BackColor = System.Drawing.Color.LightGray;
            this.button23.FlatAppearance.BorderSize = 0;
            this.button23.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button23.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button23.Location = new System.Drawing.Point(77, 152);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(74, 60);
            this.button23.TabIndex = 21;
            this.button23.Text = "CE";
            this.button23.UseVisualStyleBackColor = false;
            this.button23.Click += new System.EventHandler(this.button23_Click);
            // 
            // percentBtn
            // 
            this.percentBtn.BackColor = System.Drawing.Color.LightGray;
            this.percentBtn.FlatAppearance.BorderSize = 0;
            this.percentBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.percentBtn.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.percentBtn.Location = new System.Drawing.Point(1, 152);
            this.percentBtn.Name = "percentBtn";
            this.percentBtn.Size = new System.Drawing.Size(74, 60);
            this.percentBtn.TabIndex = 20;
            this.percentBtn.Text = "%";
            this.percentBtn.UseVisualStyleBackColor = false;
            this.percentBtn.Click += new System.EventHandler(this.percentOp_click);
            // 
            // button25
            // 
            this.button25.BackColor = System.Drawing.SystemColors.ControlLight;
            this.button25.FlatAppearance.BorderSize = 0;
            this.button25.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button25.Font = new System.Drawing.Font("Nirmala UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button25.ForeColor = System.Drawing.SystemColors.GrayText;
            this.button25.Location = new System.Drawing.Point(1, 117);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(53, 34);
            this.button25.TabIndex = 24;
            this.button25.Text = "MC";
            this.button25.UseVisualStyleBackColor = false;
            // 
            // button26
            // 
            this.button26.BackColor = System.Drawing.SystemColors.ControlLight;
            this.button26.FlatAppearance.BorderSize = 0;
            this.button26.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button26.Font = new System.Drawing.Font("Nirmala UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button26.ForeColor = System.Drawing.SystemColors.GrayText;
            this.button26.Location = new System.Drawing.Point(55, 117);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(53, 34);
            this.button26.TabIndex = 25;
            this.button26.Text = "MR";
            this.button26.UseVisualStyleBackColor = false;
            // 
            // button27
            // 
            this.button27.BackColor = System.Drawing.SystemColors.ControlLight;
            this.button27.FlatAppearance.BorderSize = 0;
            this.button27.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button27.Font = new System.Drawing.Font("Nirmala UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button27.Location = new System.Drawing.Point(109, 117);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(53, 34);
            this.button27.TabIndex = 26;
            this.button27.Text = "M+";
            this.button27.UseVisualStyleBackColor = false;
            // 
            // button28
            // 
            this.button28.BackColor = System.Drawing.SystemColors.ControlLight;
            this.button28.FlatAppearance.BorderSize = 0;
            this.button28.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button28.Font = new System.Drawing.Font("Nirmala UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button28.Location = new System.Drawing.Point(163, 117);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(53, 34);
            this.button28.TabIndex = 27;
            this.button28.Text = "M-";
            this.button28.UseVisualStyleBackColor = false;
            // 
            // button29
            // 
            this.button29.BackColor = System.Drawing.SystemColors.ControlLight;
            this.button29.FlatAppearance.BorderSize = 0;
            this.button29.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button29.Font = new System.Drawing.Font("Nirmala UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button29.Location = new System.Drawing.Point(217, 117);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(53, 34);
            this.button29.TabIndex = 28;
            this.button29.Text = "MS";
            this.button29.UseVisualStyleBackColor = false;
            // 
            // button30
            // 
            this.button30.BackColor = System.Drawing.SystemColors.ControlLight;
            this.button30.FlatAppearance.BorderSize = 0;
            this.button30.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button30.Font = new System.Drawing.Font("Nirmala UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button30.ForeColor = System.Drawing.SystemColors.GrayText;
            this.button30.Location = new System.Drawing.Point(271, 117);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(49, 34);
            this.button30.TabIndex = 29;
            this.button30.Text = "M`";
            this.button30.UseVisualStyleBackColor = false;
            // 
            // resultTextBox
            // 
            this.resultTextBox.BackColor = System.Drawing.SystemColors.ControlLight;
            this.resultTextBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.resultTextBox.Font = new System.Drawing.Font("Malgun Gothic", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.resultTextBox.Location = new System.Drawing.Point(12, 67);
            this.resultTextBox.Name = "resultTextBox";
            this.resultTextBox.Size = new System.Drawing.Size(297, 39);
            this.resultTextBox.TabIndex = 30;
            this.resultTextBox.Text = "0";
            this.resultTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(43, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 20);
            this.label1.TabIndex = 31;
            this.label1.Text = "Standard";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.button1.BackgroundImage = global::WIN10Calculator.Properties.Resources.icons8_menu_128;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Nirmala UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.GrayText;
            this.button1.Location = new System.Drawing.Point(1, 6);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(36, 20);
            this.button1.TabIndex = 24;
            this.button1.UseVisualStyleBackColor = false;
            // 
            // historyBtn
            // 
            this.historyBtn.BackColor = System.Drawing.SystemColors.ControlLight;
            this.historyBtn.BackgroundImage = global::WIN10Calculator.Properties.Resources.icons8_time_machine_32;
            this.historyBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.historyBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.historyBtn.FlatAppearance.BorderSize = 0;
            this.historyBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.historyBtn.Font = new System.Drawing.Font("Nirmala UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.historyBtn.ForeColor = System.Drawing.SystemColors.GrayText;
            this.historyBtn.Location = new System.Drawing.Point(290, 3);
            this.historyBtn.Name = "historyBtn";
            this.historyBtn.Size = new System.Drawing.Size(28, 24);
            this.historyBtn.TabIndex = 24;
            this.historyBtn.UseVisualStyleBackColor = false;
            // 
            // clrBtn
            // 
            this.clrBtn.AutoSize = true;
            this.clrBtn.BackColor = System.Drawing.Color.LightGray;
            this.clrBtn.BackgroundImage = global::WIN10Calculator.Properties.Resources.icons8_clear_symbol_20;
            this.clrBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.clrBtn.FlatAppearance.BorderSize = 0;
            this.clrBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.clrBtn.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clrBtn.Location = new System.Drawing.Point(229, 152);
            this.clrBtn.Name = "clrBtn";
            this.clrBtn.Size = new System.Drawing.Size(91, 60);
            this.clrBtn.TabIndex = 23;
            this.clrBtn.UseVisualStyleBackColor = false;
            this.clrBtn.Click += new System.EventHandler(this.clrBtn_Click);
            // 
            // button19
            // 
            this.button19.BackColor = System.Drawing.Color.LightGray;
            this.button19.BackgroundImage = global::WIN10Calculator.Properties.Resources.icons8_square_number_16;
            this.button19.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button19.FlatAppearance.BorderSize = 0;
            this.button19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button19.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button19.Location = new System.Drawing.Point(77, 213);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(74, 60);
            this.button19.TabIndex = 17;
            this.button19.UseVisualStyleBackColor = false;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // tempLabel
            // 
            this.tempLabel.AutoSize = true;
            this.tempLabel.Font = new System.Drawing.Font("HoloLens MDL2 Assets", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tempLabel.ForeColor = System.Drawing.SystemColors.GrayText;
            this.tempLabel.Location = new System.Drawing.Point(289, 37);
            this.tempLabel.Name = "tempLabel";
            this.tempLabel.Size = new System.Drawing.Size(19, 15);
            this.tempLabel.TabIndex = 31;
            this.tempLabel.Text = "00";
            this.tempLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ClientSize = new System.Drawing.Size(321, 517);
            this.Controls.Add(this.tempLabel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.resultTextBox);
            this.Controls.Add(this.button30);
            this.Controls.Add(this.button29);
            this.Controls.Add(this.button28);
            this.Controls.Add(this.button27);
            this.Controls.Add(this.button26);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.historyBtn);
            this.Controls.Add(this.button25);
            this.Controls.Add(this.clrBtn);
            this.Controls.Add(this.button22);
            this.Controls.Add(this.button23);
            this.Controls.Add(this.percentBtn);
            this.Controls.Add(this.divBtn);
            this.Controls.Add(this.rootBtn);
            this.Controls.Add(this.button19);
            this.Controls.Add(this.button20);
            this.Controls.Add(this.mulBtn);
            this.Controls.Add(this.nineBtn);
            this.Controls.Add(this.eightBtn);
            this.Controls.Add(this.sevenBtn);
            this.Controls.Add(this.minusBtn);
            this.Controls.Add(this.sixBtn);
            this.Controls.Add(this.fiveBtn);
            this.Controls.Add(this.fourBtn);
            this.Controls.Add(this.plusBtn);
            this.Controls.Add(this.threeBtn);
            this.Controls.Add(this.twoBtn);
            this.Controls.Add(this.oneBtn);
            this.Controls.Add(this.eqBtn);
            this.Controls.Add(this.decPointBtn);
            this.Controls.Add(this.zeroBtn);
            this.Controls.Add(this.plusOrMinusBtn);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Calculator";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button plusOrMinusBtn;
        private System.Windows.Forms.Button zeroBtn;
        private System.Windows.Forms.Button decPointBtn;
        private System.Windows.Forms.Button eqBtn;
        private System.Windows.Forms.Button plusBtn;
        private System.Windows.Forms.Button threeBtn;
        private System.Windows.Forms.Button twoBtn;
        private System.Windows.Forms.Button oneBtn;
        private System.Windows.Forms.Button minusBtn;
        private System.Windows.Forms.Button sixBtn;
        private System.Windows.Forms.Button fiveBtn;
        private System.Windows.Forms.Button fourBtn;
        private System.Windows.Forms.Button mulBtn;
        private System.Windows.Forms.Button nineBtn;
        private System.Windows.Forms.Button eightBtn;
        private System.Windows.Forms.Button sevenBtn;
        private System.Windows.Forms.Button divBtn;
        private System.Windows.Forms.Button rootBtn;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button clrBtn;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button percentBtn;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.TextBox resultTextBox;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button historyBtn;
        private System.Windows.Forms.Label tempLabel;
    }
}

